#' @rdname odds

invOdds <- function(x) x / (1 + x)