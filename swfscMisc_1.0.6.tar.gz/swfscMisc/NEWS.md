# swfscMisc 1.0.6

### Additions

* Added NEWS.md
* Added 'diversity' function (moved from strataG package)
* Added 'isBetween' function to test if a number is between two numbers

### Changes

* Updated README.md

### Bug Fixes

* Fixed 'zero.pad' to pad to largest integer.


