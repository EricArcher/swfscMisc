#' @rdname odds

logOdds <- function(x) log(odds(x))